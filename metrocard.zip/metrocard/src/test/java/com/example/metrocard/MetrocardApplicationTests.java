package com.example.metrocard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MetrocardApplicationTests {

	@Test
	void contextLoads() {
	}

}
