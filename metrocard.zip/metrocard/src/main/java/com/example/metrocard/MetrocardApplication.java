package com.example.metrocard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MetrocardApplication {

	public static void main(String[] args) {
		SpringApplication.run(MetrocardApplication.class, args);
	}

}
